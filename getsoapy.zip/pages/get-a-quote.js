// // import { useState } from 'react';
// // import Layout from '../components/layout';

// // export default function GetAQuote() {
// //   const [formData, setFormData] = useState({
// //     name: '',
// //     company: '',
// //     email: '',
// //     phone: '',
// //     address: '',
// //     service: '',
// //     description: ''
// //   });
// //   const [files, setFiles] = useState([]);
// //   const [isSubmitting, setIsSubmitting] = useState(false);
// //   const [isSubmitted, setIsSubmitted] = useState(false);

// //   const handleChange = (e) => {
// //     setFormData({
// //       ...formData,
// //       [e.target.name]: e.target.value
// //     });
// //   };

// //   const handleFileChange = (e) => {
// //     if (e.target.files.length > 0) {
// //       const newFiles = Array.from(e.target.files).slice(0, 3);
// //       setFiles(newFiles);
// //     }
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     setIsSubmitting(true);
    
// //     // Simulate API call
// //     setTimeout(() => {
// //       setIsSubmitting(false);
// //       setIsSubmitted(true);
      
// //       // Here you would typically:
// //       // 1. Send email to ops
// //       // 2. Forward to GetSoapy webhook
// //       // 3. Store minimal lead data
// //     }, 2000);
// //   };

// //   if (isSubmitted) {
// //     return (
// //       <Layout>
// //         <section className="py-16 bg-bgLight">
// //           <div className="container max-w-2xl text-center">
// //             <div className="bg-white p-8 rounded-lg shadow-sm">
// //               <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
// //                 <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
// //                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
// //                 </svg>
// //               </div>
// //               <h1 className="text-3xl font-headline mb-4">Thank You!</h1>
// //               <p className="text-lg text-darkSlate mb-6">
// //                 We've received your quote request and will contact you within 2 hours.
// //               </p>
// //               <p className="text-darkSlate">
// //                 You may also receive a follow-up from GetSoapy to collect additional details about your requirements.
// //               </p>
// //             </div>
// //           </div>
// //         </section>
// //       </Layout>
// //     );
// //   }

// //   return (
// //     <Layout>
// //       {/* Hero Section */}
// //       <section className="bg-primary text-white py-16">
// //         <div className="container">
// //           <h1 className="text-4xl font-headline font-bold mb-4">Get a Quote</h1>
// //           <p className="text-xl max-w-3xl">
// //             Tell us about your project and we'll provide a detailed, no-obligation quote within 24 hours.
// //           </p>
// //         </div>
// //       </section>

// //       {/* Form Section */}
// //       <section className="py-16 bg-bgLight">
// //         <div className="container max-w-2xl">
// //           <div className="bg-white p-8 rounded-lg shadow-sm">
// //             <form onSubmit={handleSubmit}>
// //               <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
// //                 <div>
// //                   <label htmlFor="name" className="block text-sm font-medium text-darkSlate mb-2">
// //                     Full Name *
// //                   </label>
// //                   <input
// //                     type="text"
// //                     id="name"
// //                     name="name"
// //                     required
// //                     value={formData.name}
// //                     onChange={handleChange}
// //                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
// //                   />
// //                 </div>
// //                 <div>
// //                   <label htmlFor="company" className="block text-sm font-medium text-darkSlate mb-2">
// //                     Company Name *
// //                   </label>
// //                   <input
// //                     type="text"
// //                     id="company"
// //                     name="company"
// //                     required
// //                     value={formData.company}
// //                     onChange={handleChange}
// //                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
// //                   />
// //                 </div>
// //               </div>

// //               <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
// //                 <div>
// //                   <label htmlFor="email" className="block text-sm font-medium text-darkSlate mb-2">
// //                     Email Address *
// //                   </label>
// //                   <input
// //                     type="email"
// //                     id="email"
// //                     name="email"
// //                     required
// //                     value={formData.email}
// //                     onChange={handleChange}
// //                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
// //                   />
// //                 </div>
// //                 <div>
// //                   <label htmlFor="phone" className="block text-sm font-medium text-darkSlate mb-2">
// //                     Phone Number *
// //                   </label>
// //                   <input
// //                     type="tel"
// //                     id="phone"
// //                     name="phone"
// //                     required
// //                     value={formData.phone}
// //                     onChange={handleChange}
// //                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
// //                   />
// //                 </div>
// //               </div>

// //               <div className="mb-6">
// //                 <label htmlFor="address" className="block text-sm font-medium text-darkSlate mb-2">
// //                   Site Address *
// //                 </label>
// //                 <input
// //                   type="text"
// //                   id="address"
// //                   name="address"
// //                   required
// //                   placeholder="Start typing your address..."
// //                   value={formData.address}
// //                   onChange={handleChange}
// //                   className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
// //                 />
// //               </div>

// //               <div className="mb-6">
// //                 <label htmlFor="service" className="block text-sm font-medium text-darkSlate mb-2">
// //                   Service Required *
// //                 </label>
// //                 <select
// //                   id="service"
// //                   name="service"
// //                   required
// //                   value={formData.service}
// //                   onChange={handleChange}
// //                   className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
// //                 >
// //                   <option value="">Select a service</option>
// //                   <option value="grounds-maintenance">Grounds Maintenance</option>
// //                   <option value="landscaping-softworks">Landscaping & Softworks</option>
// //                   <option value="reactive-property-maintenance">Reactive Property Maintenance</option>
// //                   <option value="tree-work">Tree Work</option>
// //                   <option value="seasonal-winter-services">Seasonal & Winter Services</option>
// //                 </select>
// //               </div>

// //               <div className="mb-6">
// //                 <label htmlFor="description" className="block text-sm font-medium text-darkSlate mb-2">
// //                   Project Description *
// //                 </label>
// //                 <textarea
// //                   id="description"
// //                   name="description"
// //                   required
// //                   rows={5}
// //                   value={formData.description}
// //                   onChange={handleChange}
// //                   placeholder="Please describe your project requirements, including any specific challenges or timelines..."
// //                   className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
// //                 ></textarea>
// //               </div>

// //               <div className="mb-8">
// //                 <label className="block text-sm font-medium text-darkSlate mb-2">
// //                   Upload Images (Optional, max 3 files, 2MB each)
// //                 </label>
// //                 <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
// //                   <input
// //                     type="file"
// //                     multiple
// //                     accept="image/*"
// //                     onChange={handleFileChange}
// //                     className="hidden"
// //                     id="file-upload"
// //                   />
// //                   <label htmlFor="file-upload" className="cursor-pointer">
// //                     <svg className="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
// //                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
// //                     </svg>
// //                     <p className="text-gray-600">Click to upload images or drag and drop</p>
// //                     <p className="text-sm text-gray-500 mt-1">PNG, JPG, GIF up to 2MB each</p>
// //                   </label>
// //                 </div>
// //                 {files.length > 0 && (
// //                   <div className="mt-3">
// //                     <p className="text-sm font-medium text-darkSlate mb-2">Selected files:</p>
// //                     <ul className="text-sm text-gray-600">
// //                       {files.map((file, index) => (
// //                         <li key={index}>{file.name}</li>
// //                       ))}
// //                     </ul>
// //                   </div>
// //                 )}
// //               </div>

// //               <div className="flex items-center mb-6">
// //                 <input
// //                   type="checkbox"
// //                   id="privacy"
// //                   required
// //                   className="w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
// //                 />
// //                 <label htmlFor="privacy" className="ml-2 text-sm text-darkSlate">
// //                   I agree to the privacy policy and terms of service
// //                 </label>
// //               </div>

// //               <button
// //                 type="submit"
// //                 disabled={isSubmitting}
// //                 className="w-full btn btn-primary text-lg py-3 disabled:opacity-50"
// //               >
// //                 {isSubmitting ? 'Submitting...' : 'Submit Quote Request'}
// //               </button>
// //             </form>
// //           </div>
// //         </div>
// //       </section>
// //     </Layout>
// //   );
// // }




// // pages/get-a-quote.js
// import { useState } from 'react';
// import Layout from '../components/layout';
// import getSoapyAPI from '../lib/getSoapy';

// export default function GetAQuote() {
//   const [formData, setFormData] = useState({
//     name: '',
//     company: '',
//     email: '',
//     phone: '',
//     address: '',
//     service: '',
//     description: ''
//   });
//   const [files, setFiles] = useState([]);
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [isSubmitted, setIsSubmitted] = useState(false);
//   const [error, setError] = useState('');

//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value
//     });
//   };

//   const handleFileChange = (e) => {
//     if (e.target.files.length > 0) {
//       const newFiles = Array.from(e.target.files).slice(0, 3);
//       setFiles(newFiles);
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setIsSubmitting(true);
//     setError('');

//     try {
//       // Prepare lead data for GetSoapy
//       const leadData = {
//         source: 'website-quote-form',
//         contact: {
//           name: formData.name,
//           company: formData.company,
//           email: formData.email,
//           phone: formData.phone
//         },
//         property: {
//           address: formData.address
//         },
//         service_request: {
//           service_type: formData.service,
//           description: formData.description,
//           urgency: 'standard'
//         },
//         metadata: {
//           form_submitted_at: new Date().toISOString(),
//           files_count: files.length
//         }
//       };

//       // Send to GetSoapy API
//       const response = await fetch('/api/leads', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           leadData,
//           recaptchaToken: await getRecaptchaToken()
//         }),
//       });

//       if (!response.ok) {
//         throw new Error('Failed to submit quote request');
//       }

//       // Handle file uploads if any
//       if (files.length > 0) {
//         await uploadFiles(files, formData.email);
//       }

//       setIsSubmitted(true);
//     } catch (err) {
//       console.error('Submission error:', err);
//       setError('Sorry, there was an error submitting your request. Please try again or contact us directly.');
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   const getRecaptchaToken = async () => {
//     // reCAPTCHA v3 implementation
//     if (typeof window.grecaptcha !== 'undefined') {
//       return await window.grecaptcha.execute(process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY, {
//         action: 'quote_submit'
//       });
//     }
//     return null;
//   };

//   const uploadFiles = async (files, clientEmail) => {
//     const uploadPromises = files.map(async (file) => {
//       const formData = new FormData();
//       formData.append('file', file);
//       formData.append('clientEmail', clientEmail);
//       formData.append('purpose', 'quote_request');

//       const response = await fetch('/api/upload', {
//         method: 'POST',
//         body: formData,
//       });

//       if (!response.ok) {
//         throw new Error(`Failed to upload file: ${file.name}`);
//       }

//       return response.json();
//     });

//     return Promise.all(uploadPromises);
//   };

//   if (isSubmitted) {
//     return (
//       <Layout>
//         <section className="py-16 bg-bgLight">
//           <div className="container max-w-2xl text-center">
//             <div className="bg-white p-8 rounded-lg shadow-sm">
//               <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
//                 <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
//                 </svg>
//               </div>
//               <h1 className="text-3xl font-headline mb-4">Thank You!</h1>
//               <p className="text-lg text-darkSlate mb-6">
//                 We've received your quote request and will contact you within 2 hours.
//               </p>
//               <p className="text-darkSlate mb-6">
//                 You may also receive a follow-up from GetSoapy to collect additional details about your requirements.
//               </p>
//               <div className="bg-bgLight p-4 rounded-lg text-left">
//                 <h3 className="font-headline mb-2">What happens next?</h3>
//                 <ul className="text-sm text-darkSlate space-y-1">
//                   <li>• Our team will review your requirements</li>
//                   <li>• We'll schedule a site survey if needed</li>
//                   <li>• You'll receive a detailed quote within 24 hours</li>
//                   <li>• You can track your request in GetSoapy</li>
//                 </ul>
//               </div>
//             </div>
//           </div>
//         </section>
//       </Layout>
//     );
//   }

//   return (
//     <Layout>
//       <section className="bg-primary text-white py-16">
//         <div className="container">
//           <h1 className="text-4xl font-headline font-bold mb-4">Get a Quote</h1>
//           <p className="text-xl max-w-3xl">
//             Tell us about your project and we'll provide a detailed, no-obligation quote within 24 hours.
//           </p>
//         </div>
//       </section>

//       <section className="py-16 bg-bgLight">
//         <div className="container max-w-2xl">
//           <div className="bg-white p-8 rounded-lg shadow-sm">
//             {error && (
//               <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
//                 {error}
//               </div>
//             )}
            
//                  <form onSubmit={handleSubmit}>
//               <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
//                 <div>
//                   <label htmlFor="name" className="block text-sm font-medium text-darkSlate mb-2">
//                     Full Name *
//                   </label>
//                   <input
//                     type="text"
//                     id="name"
//                     name="name"
//                     required
//                     value={formData.name}
//                     onChange={handleChange}
//                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
//                   />
//                 </div>
//                 <div>
//                   <label htmlFor="company" className="block text-sm font-medium text-darkSlate mb-2">
//                     Company Name *
//                   </label>
//                   <input
//                     type="text"
//                     id="company"
//                     name="company"
//                     required
//                     value={formData.company}
//                     onChange={handleChange}
//                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
//                   />
//                 </div>
//               </div>

//               <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
//                 <div>
//                   <label htmlFor="email" className="block text-sm font-medium text-darkSlate mb-2">
//                     Email Address *
//                   </label>
//                   <input
//                     type="email"
//                     id="email"
//                     name="email"
//                     required
//                     value={formData.email}
//                     onChange={handleChange}
//                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
//                   />
//                 </div>
//                 <div>
//                   <label htmlFor="phone" className="block text-sm font-medium text-darkSlate mb-2">
//                     Phone Number *
//                   </label>
//                   <input
//                     type="tel"
//                     id="phone"
//                     name="phone"
//                     required
//                     value={formData.phone}
//                     onChange={handleChange}
//                     className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
//                   />
//                 </div>
//               </div>

//               <div className="mb-6">
//                 <label htmlFor="address" className="block text-sm font-medium text-darkSlate mb-2">
//                   Site Address *
//                 </label>
//                 <input
//                   type="text"
//                   id="address"
//                   name="address"
//                   required
//                   placeholder="Start typing your address..."
//                   value={formData.address}
//                   onChange={handleChange}
//                   className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
//                 />
//               </div>

//               <div className="mb-6">
//                 <label htmlFor="service" className="block text-sm font-medium text-darkSlate mb-2">
//                   Service Required *
//                 </label>
//                 <select
//                   id="service"
//                   name="service"
//                   required
//                   value={formData.service}
//                   onChange={handleChange}
//                   className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
//                 >
//                   <option value="">Select a service</option>
//                   <option value="grounds-maintenance">Grounds Maintenance</option>
//                   <option value="landscaping-softworks">Landscaping & Softworks</option>
//                   <option value="reactive-property-maintenance">Reactive Property Maintenance</option>
//                   <option value="tree-work">Tree Work</option>
//                   <option value="seasonal-winter-services">Seasonal & Winter Services</option>
//                 </select>
//               </div>

//               <div className="mb-6">
//                 <label htmlFor="description" className="block text-sm font-medium text-darkSlate mb-2">
//                   Project Description *
//                 </label>
//                 <textarea
//                   id="description"
//                   name="description"
//                   required
//                   rows={5}
//                   value={formData.description}
//                   onChange={handleChange}
//                   placeholder="Please describe your project requirements, including any specific challenges or timelines..."
//                   className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
//                 ></textarea>
//               </div>

//               <div className="mb-8">
//                 <label className="block text-sm font-medium text-darkSlate mb-2">
//                   Upload Images (Optional, max 3 files, 2MB each)
//                 </label>
//                 <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
//                   <input
//                     type="file"
//                     multiple
//                     accept="image/*"
//                     onChange={handleFileChange}
//                     className="hidden"
//                     id="file-upload"
//                   />
//                   <label htmlFor="file-upload" className="cursor-pointer">
//                     <svg className="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
//                     </svg>
//                     <p className="text-gray-600">Click to upload images or drag and drop</p>
//                     <p className="text-sm text-gray-500 mt-1">PNG, JPG, GIF up to 2MB each</p>
//                   </label>
//                 </div>
//                 {files.length > 0 && (
//                   <div className="mt-3">
//                     <p className="text-sm font-medium text-darkSlate mb-2">Selected files:</p>
//                     <ul className="text-sm text-gray-600">
//                       {files.map((file, index) => (
//                         <li key={index}>{file.name}</li>
//                       ))}
//                     </ul>
//                   </div>
//                 )}
//               </div>

//               <div className="flex items-center mb-6">
//                 <input
//                   type="checkbox"
//                   id="privacy"
//                   required
//                   className="w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
//                 />
//                 <label htmlFor="privacy" className="ml-2 text-sm text-darkSlate">
//                   I agree to the privacy policy and terms of service
//                 </label>
//               </div>
              
//               <button
//                 type="submit"
//                 disabled={isSubmitting}
//                 className="w-full btn btn-primary text-lg py-3 disabled:opacity-50"
//               >
//                 {isSubmitting ? 'Submitting...' : 'Submit Quote Request'}
//               </button>
//             </form>
//           </div>
//         </div>
//       </section>
//     </Layout>
//   );
// }

import { useState } from 'react';
import Layout from '../components/layout';

export default function GetAQuote() {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    address: '',
    service: '',
    description: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const getRecaptchaToken = async () => {
    if (typeof window.grecaptcha !== 'undefined') {
      return await window.grecaptcha.execute(process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY, {
        action: 'quote_submit'
      });
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      const recaptchaToken = await getRecaptchaToken();
      
      const leadData = {
        source: 'website-quote-form',
        contact: {
          name: formData.name,
          company: formData.company,
          email: formData.email,
          phone: formData.phone
        },
        property: {
          address: formData.address
        },
        service_request: {
          service_type: formData.service,
          description: formData.description,
          urgency: 'standard'
        }
      };

      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          leadData,
          recaptchaToken
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'Submission failed');
      }

      setIsSubmitted(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <Layout>
        <section className="py-16 bg-bgLight">
          <div className="container max-w-2xl text-center">
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h1 className="text-3xl font-headline mb-4">Thank You!</h1>
              <p className="text-lg text-darkSlate mb-6">
                We've received your quote request and will contact you within 2 hours.
              </p>
              <p className="text-darkSlate">
                You may also receive a follow-up from GetSoapy to collect additional details.
              </p>
            </div>
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="bg-primary text-white py-16">
        <div className="container">
          <h1 className="text-4xl font-headline font-bold mb-4">Get a Quote</h1>
          <p className="text-xl max-w-3xl">
            Tell us about your project for a detailed, no-obligation quote within 24 hours.
          </p>
        </div>
      </section>

      <section className="py-16 bg-bgLight">
        <div className="container max-w-2xl">
          <div className="bg-white p-8 rounded-lg shadow-sm">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-darkSlate mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-darkSlate mb-2">
                    Company Name *
                  </label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    required
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-darkSlate mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-darkSlate mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div className="mb-6">
                <label htmlFor="address" className="block text-sm font-medium text-darkSlate mb-2">
                  Site Address *
                </label>
                <input
                  type="text"
                  id="address"
                  name="address"
                  required
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>

              <div className="mb-6">
                <label htmlFor="service" className="block text-sm font-medium text-darkSlate mb-2">
                  Service Required *
                </label>
                <select
                  id="service"
                  name="service"
                  required
                  value={formData.service}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                >
                  <option value="">Select a service</option>
                  <option value="grounds-maintenance">Grounds Maintenance</option>
                  <option value="landscaping-softworks">Landscaping & Softworks</option>
                  <option value="reactive-property-maintenance">Reactive Property Maintenance</option>
                  <option value="tree-work">Tree Work</option>
                  <option value="seasonal-winter-services">Seasonal & Winter Services</option>
                </select>
              </div>

              <div className="mb-6">
                <label htmlFor="description" className="block text-sm font-medium text-darkSlate mb-2">
                  Project Description *
                </label>
                <textarea
                  id="description"
                  name="description"
                  required
                  rows={5}
                  value={formData.description}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn btn-primary text-lg py-3 disabled:opacity-50"
              >
                {isSubmitting ? 'Submitting...' : 'Submit Quote Request'}
              </button>
            </form>
          </div>
        </div>
      </section>
    </Layout>
  );
}