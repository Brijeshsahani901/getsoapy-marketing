import Layout from '../../components/layout';
import Link from 'next/link';

export default function GroundsMaintenance() {
  return (
    <Layout>
      <section className="bg-primary text-white py-16">
        <div className="container">
          <h1 className="text-4xl font-headline font-bold mb-4">Grounds Maintenance</h1>
          <p className="text-xl max-w-3xl">
            Professional grounds maintenance services to keep your property looking its best year-round.
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <h2 className="text-3xl font-headline mb-6">Comprehensive Grounds Care</h2>
              <p className="text-lg text-darkSlate mb-6">
                Our grounds maintenance service provides regular, scheduled care to ensure your outdoor spaces 
                remain clean, safe, and visually appealing throughout the year.
              </p>
              
              <h3 className="text-2xl font-headline mb-4">Service Includes:</h3>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-primary mr-3" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Lawn mowing and edging
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-primary mr-3" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Hedge trimming and pruning
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-primary mr-3" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Weed control and management
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-primary mr-3" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Seasonal planting and bedding
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-primary mr-3" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Litter collection and clearance
                </li>
              </ul>

              <Link href="/get-a-quote" className="btn btn-primary text-lg px-8 py-3">
                Request a Survey
              </Link>
            </div>

            <div className="bg-bgLight p-6 rounded-lg">
              <h3 className="text-xl font-headline mb-4">Service Highlights</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold">Response Time</h4>
                  <p className="text-sm">Within 2 hours for urgent requests</p>
                </div>
                <div>
                  <h4 className="font-semibold">Availability</h4>
                  <p className="text-sm">24/7 emergency service</p>
                </div>
                <div>
                  <h4 className="font-semibold">Coverage</h4>
                  <p className="text-sm">Nationwide service available</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}